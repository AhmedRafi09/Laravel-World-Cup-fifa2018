<?php $__env->startSection('content'); ?>

	<?php echo e(Form::open(['action' => 'PagesController@fileUpload', 'files' => true, 'method' => 'POST'])); ?>


	<div class="row cancel">

	    <div class="col-md-4">

	        <?php echo Form::file('image', array('class' => 'image')); ?>


	    </div>

	    <div class="col-md-4">

	        <button type="submit" class="btn btn-success">Upload</button>

	    </div>

	</div>
	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>