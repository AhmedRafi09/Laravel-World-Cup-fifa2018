<?php $__env->startSection('content'); ?>
	<hr>
	
	<div style="text-align: center;">
		<h3>Follow Us On</h3>
		<hr>
		<a href="#" class="fa fa-facebook"></a>
		<a href="https://twitter.com/fifaworldcup" class="fa fa-twitter"></a>
		<a href="#" class="fa fa-google"></a>
		<a href="#" class="fa fa-linkedin"></a>
		<a href="https://www.youtube.com/user/FIFATV" class="fa fa-youtube"></a>
		<a href="#" class="fa fa-instagram"></a>
		<a href="#" class="fa fa-pinterest"></a>
	</div>
	<hr>
	<br>
	<br>
	


	
	<footer class="text-center">

	  <p>All Rights Reserved By FIFA2018 Russia TM > Developed By  <a href="" data-toggle="tooltip" title=""><h3>Rafiul Ahmed</h3></a></p> 
	</footer>
<?php $__env->stopSection(); ?>

<style>

.row{
	display: flex;
	}
.left{
	flex: 30%;
}
.right{
	flex: 70%;
}
.fa {
  padding: 20px;
  font-size: 50px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 10px;
  border-radius: 60%;
}

.fa:hover {
    opacity: 0.8;
}

.fa-facebook {
  background: #183AAD;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

.fa-pinterest {
  background: #cb2027;
  color: white;
}

.person {
  border: 10px solid transparent;
  margin-bottom: 25px;
  width: 100%;
  height: 75%;
  opacity: 0.7;
}
.person:hover {
  border-color: #f1f1f1;
}

/* Add a dark background color to the footer */
footer {
  background-color: #5F0600;
  color: #f5f5f5;
  padding: 32px;
  margin-bottom: 0px;
  width: 100%;
}

footer a {
  color: #f5f5f5;
}

footer a:hover {
  color: #777;
  text-decoration: none;
}

</style>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>