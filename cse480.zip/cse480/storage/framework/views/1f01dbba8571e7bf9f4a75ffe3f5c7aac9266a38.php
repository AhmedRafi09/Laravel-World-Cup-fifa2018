<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->isAdmin == 1): ?>

	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
			<h2>Admin Dashboard</h2>
	</div>
		
	<hr>
	<div style="display: flex;text-align: center;">
		<div class="well" style="flex: 25%; background-color: #7B1414; color: white;">
			<h3><a href="/matches/create">ADD A MATCH</a></h3>	    
		</div>

		<div class="well" style="flex: 25%; background-color: #580046; color: white;">
			<h3><a href="/players/create">ADD A PLAYER</a></h3>	    
		</div>

		<div class="well" style="flex: 25%; background-color: #003E93; color: white;">
			<h3><a href="/teams/create">ADD A TEAM</a></h3>	    
		</div>

		<div class="well" style="flex: 25%; background-color: #2C0058; color: white;">
			<h3><a href="/posts/create">ADD A BLOG POST</a></h3>	    
		</div>
	</div>
	
</div>
<?php else: ?>
	<h3>Unauthorized Request!</h3>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>