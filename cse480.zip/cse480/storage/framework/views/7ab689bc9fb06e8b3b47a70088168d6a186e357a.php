<?php $__env->startSection('content'); ?>

	<a href="/posts" class="btn btn-default">Back To All Posts</a>
	<hr>
	<div class="well" style="width: 100%; background-color: #7B1414; color: white;">
		<h2><?php echo e($post->title); ?></h2>
		<small>Written at <?php echo e($post->created_at); ?></small>
		<div>
			<?php echo e($post->body); ?>

		</div>
		
	</div>
	<hr>
	<div class="container">
		<h3>Comments</h3>
		<ul class="list-group">
			<?php $__currentLoopData = $post->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="list-group-item">
					
					<h4><?php echo e($comment->body); ?></h4>
					<h5><?php echo e($comment->created_at->diffForHumans()); ?> &nbsp;</h5>
				</li>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>	
	</div>

	<hr>

	<form method="post" action="/posts/<?php echo e($post->id); ?>/comment">
			<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
			<input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<textarea class="form-control" placeholder="Comment Here" name="body"></textarea>
			</div>
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Comment</button>
			</div>
	</form>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>