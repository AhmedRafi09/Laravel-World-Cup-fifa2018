<?php $__env->startSection('content'); ?>
	<div style="text-align: center;">
		<div style="display: flex;">
			<div class="well" style="flex: 25%;">
				<h3><a href="/matches/create">ADD A MATCH</a></h3>	    
			</div>

			<div class="well" style="flex: 25%;">
				<h3><a href="/players/create">ADD A PLAYER</a></h3>	    
			</div>

			<div class="well" style="flex: 25%;">
				<h3><a href="/teams/create">ADD A TEAM</a></h3>	    
			</div>

			<div class="well" style="flex: 25%;">
				<h3><a href="/posts/create">ADD A BLOG POST</a></h3>	    
			</div>
		</div>
		
	</div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>