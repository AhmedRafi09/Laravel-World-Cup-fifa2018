<?php $__env->startSection('content'); ?>
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Blog Posts</h2>
	</div>

	<div class="container">
		<?php if(count($posts) > 0): ?>
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="well" style="width: 100%;">
				<h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
				<small>Written at <?php echo e($post->created_at); ?></small>
				<br>
				<br>
				<?php if(auth()->user()->isAdmin == 1): ?>
					<a href="/posts/edit_post/<?php echo e($post->id); ?>" class="btn btn-primary" style="float: left;">EDIT</a>
			      
			      	<?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST']); ?>


			      	<?php echo Form::hidden('_method', 'DELETE'); ?>

			      	<?php echo Form::submit('DELETE', ['class' => 'btn btn-danger']); ?>

			      	<?php echo Form::close(); ?>

			    <?php endif; ?>
			</div>
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($posts->links()); ?>

	</div>
	
	
	<?php else: ?>
		<p>No Posts Found!</p>
	<?php endif; ?>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>