<?php $__env->startSection('content'); ?>
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Players</h2>
		<p></p> 
	</div>
	<br><br>
	<div class="container">
	<table class="table table-light">
	  <thead>
	    <tr>
	      <th scope="col">Name</th>
	      <th scope="col">Country</th>
	      <th scope="col">Age</th>
	      <th scope="col">Position</th>
	      <th scope="col">Matches</th>
	    </tr>
	  </thead>
	  <?php if(Auth::guest()): ?>
	  	 <tbody>
			<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
			    <tr>
			      <td><h2><?php echo e($player->name); ?></h2></td>
			      <td><h3><?php echo e($player->country); ?></h3></td>
			      <td><h3><?php echo e($player->age); ?></h3></td>
			      <td><h3><?php echo e($player->position); ?></h3></td>
			      <td><h3><?php echo e($player->matches); ?></h3></td>
			    </tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  </tbody>
	  <?php elseif(auth()->user()->isAdmin == 1): ?>
	  <tbody>
		<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		    <tr>
		      <td><?php echo e($player->name); ?></td>
		      <td><?php echo e($player->country); ?></td>
		      <td><?php echo e($player->age); ?></td>
		      <td><?php echo e($player->position); ?></td>
		      <td><?php echo e($player->matches); ?></td>
		      <td><a href="/players/edit_player/<?php echo e($player->id); ?>" class="btn btn-primary">EDIT</a></td>
		      <td>
		      	<?php echo Form::open(['action' => ['PlayersController@destroy', $player->id], 'method' => 'POST']); ?>


		      	<?php echo Form::hidden('_method', 'DELETE'); ?>

		      	<?php echo Form::submit('DELETE', ['class' => 'btn btn-danger']); ?>

		      	<?php echo Form::close(); ?>

		      </td>
		    </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  </tbody>

	 <?php elseif(Auth::user()): ?>
	  	<tbody>
		<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		    <tr>
		      <td><?php echo e($player->name); ?></td>
		      <td><?php echo e($player->country); ?></td>
		      <td><?php echo e($player->age); ?></td>
		      <td><?php echo e($player->position); ?></td>
		      <td><?php echo e($player->matches); ?></td>
		    </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  </tbody>
	  
	 <?php endif; ?>
	</table>
</div>
	
	
<?php echo e($players->Links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>