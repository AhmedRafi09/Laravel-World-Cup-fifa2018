<?php $__env->startSection('content'); ?>
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Groups & Standings</h2>
		<p></p> 
	</div>
	
	<br><br>
	 <div class="container">
		<p><?php echo e(count($groups)); ?></p>
		<table class="table table-light">
		  <thead>
		    <tr>
		      <th scope="col">GRP</th>
		      <th scope="col">Team</th>
		      <th scope="col">MP</th>
		      <th scope="col">W</th>
		      <th scope="col">D</th>
		      <th scope="col">L</th>
		      <th scope="col">GF</th>
		      <th scope="col">GA</th>
		      <th scope="col">+/-</th>
		      <th scope="col">PTS</th>
		    </tr>
		  </thead>
		  <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  	<tbody>
					
				    <tr>
				      <td rowspan='4'><h2><strong><?php echo e($group->group_name); ?></strong></h2></td>
				      <td><h3><?php echo e($group->country_name); ?></h3></td>
				      <td><h3><?php echo e($group->match_played); ?></h3></td>
				      <td><h3><?php echo e($group->match_won); ?></h3></td>
				      <td><h3><?php echo e($group->match_drawn); ?></h3></td>
				      <td><h3><?php echo e($group->match_lost); ?></h3></td>
				      <td><h3><?php echo e($group->goals_for); ?></h3></td>
				      <td><h3><?php echo e($group->goals_against); ?></h3></td>
				      <td><h3><?php echo e($group->goal_diff); ?></h3></td>
				      <td><h3><?php echo e($group->points); ?></h3></td>

				    </tr>
				

		  	</tbody>
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>