<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->isAdmin == 1): ?>
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
        	<h2>CREATE POST</h2>

        	<?php echo e(Form::open(['action' => 'PostsController@store', 'method' => 'POST'])); ?>

        	<div class="form-group">
        		<?php echo e(Form::label('title', 'Title')); ?>

        		<?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>	
        	</div>

        	<div class="form-group">
        		<?php echo e(Form::label('body', 'Body')); ?>

        		<?php echo e(Form::textarea('body', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>	
        	</div>

    		<?php echo e(Form::submit('Cancel', ['class' => 'btn btn-danger'])); ?>

    		<?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

			<?php echo e(Form::close()); ?>


        </div>
    </div>
<?php else: ?>
    <h2 class="alert alert-danger">Unauthorized!!</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>