<?php $__env->startSection('content'); ?>

	<div class="well" style="width: 100%; text-align: center; background-color: #13395A; color: white;">
		<img src="/images/teams/<?php echo e($team->flag); ?>" alt="Lights" style="width:20%; height: 15%;">
		<h1><?php echo e($team->team_name); ?></h1>
		<h2>Coach/Team Manager : <?php echo e($team->coach); ?></h2>
		<p></p> 
	</div>

	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2 style="text-align: center;">Players</h2>
	</div>
	
	<hr>
	

	<div class="container">
		<table class="table table-light">
		  	<thead>
			    <tr>
			      <th scope="col">Name</th>
			      <th scope="col">Position</th>
			      <th scope="col">Age</th>
			      <th scope="col">Matches</th>
			    </tr>
		  	</thead>
	  	  	<tbody>
				<?php $__currentLoopData = $team->player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
				    <tr>
				      <td><h2><?php echo e($player->name); ?></h2></td>
				      <td><h3><?php echo e($player->position); ?></h3></td>
				      <td><h3><?php echo e($player->age); ?></h3></td>
				      <td><h3><?php echo e($player->matches); ?></h3></td>
				    </tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  		</tbody>
		</table>
	</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>