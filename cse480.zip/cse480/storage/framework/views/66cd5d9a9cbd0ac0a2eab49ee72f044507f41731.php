<?php $__env->startSection('content'); ?>

<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
	<h2>Matches From Round Of 16</h2>
</div>
<div class="container">
	<?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  <div class="well" style="width: 100%;">
	  	<div class="row">
	  		<div class="left">
		  		<h2><?php echo e($match->team_1); ?>  <?php echo e($match->goal_team_1); ?> - <?php echo e($match->goal_team_2); ?>  <?php echo e($match->team_2); ?></h2>
	  		</div>
	    
		    <div class="right;">	
				<h4>City: <?php echo e($match->city); ?></h4>      
		    	<h4>Venue: <?php echo e($match->venue); ?></h4>
		    </div>
	  	</div>    
	  </div> 
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
     

<?php $__env->stopSection(); ?>

<style type="text/css">
	.row{
		display: flex;
	}
	.left{
		flex: 30%;
	}
	.right{
		flex: 70%;
	}
</style>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>