<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->isAdmin == 1): ?>
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
            <h2>ADD A PLAYER</h2>

            <?php echo e(Form::open(['action' => 'MatchesController@store', 'method' => 'POST'])); ?>


            <div class="form-group">
                <?php echo e(Form::label('venue', 'Venue')); ?>

                <?php echo e(Form::text('venue', '', ['class' => 'form-control', 'placeholder' => 'Venue'])); ?>    
            </div>
            
            <div class="form-group">
                <?php echo e(Form::label('city', 'City')); ?>

                <?php echo e(Form::text('city', '', ['class' => 'form-control', 'placeholder' => 'City'])); ?>  
            </div>

            

            <div class="form-group">
                <?php echo e(Form::label('team_1', 'First Team')); ?>

                <?php echo e(Form::text('team_1', '', ['class' => 'form-control', 'placeholder' => 'First Team'])); ?>  
            </div>

            <div class="form-group">
                <?php echo e(Form::label('goal_team_1', 'Goals')); ?>

                <?php echo e(Form::text('goal_team_1', '', ['class' => 'form-control', 'placeholder' => 'Goals'])); ?>    
            </div>

            <div class="form-group">
                <?php echo e(Form::label('team_2', 'Second Team')); ?>

                <?php echo e(Form::text('team_2', '', ['class' => 'form-control', 'placeholder' => 'Second Team'])); ?>  
            </div>

            <div class="form-group">
                <?php echo e(Form::label('goal_team_2', 'Goals')); ?>

                <?php echo e(Form::text('goal_team_2', '', ['class' => 'form-control', 'placeholder' => 'Goals'])); ?>    
            </div>

            <?php echo e(Form::submit('Cancel', ['class' => 'btn btn-danger'])); ?>

            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>



            
                
                


                    
        </div>
    </div>
<?php else: ?>
    <h2 class="alert alert-danger">Unauthorized!!</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>