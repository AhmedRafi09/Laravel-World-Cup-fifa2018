<?php $__env->startSection('content'); ?>
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Teams Of World Cup 2018</h2>
	</div>
	<br>
		
	<div class="row">

		<?php if(count($teams) > 0): ?>
			<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			    <div class="col-md-3">
			      <div class="thumbnail">
			        <a href="/details/<?php echo e($team->id); ?>" target="_self" value="<?php echo e($team->team_name); ?>">
			          <img src="/images/teams/<?php echo e($team->flag); ?>" alt="Lights" style="width:100%;">
			          <div class="caption">
			   		  	<h3 style="text-align: center;"><?php echo e($team->team_name); ?></h3>
			          </div>
			        </a>
			      </div>
			    </div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
			<p>No Team Found!</p>
		<?php endif; ?>

	</div>

<?php $__env->stopSection(); ?>

















<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>