<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->isAdmin == 1): ?>
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
            <h2>Create A Team</h2>

            <?php echo e(Form::open(['action' => 'TeamsController@store', 'files' => true, 'method' => 'POST'])); ?>


            <div class="form-group">
                <?php echo e(Form::label('team_name', 'Team Name')); ?>

                <?php echo e(Form::text('team_name', '', ['class' => 'form-control', 'placeholder' => 'Team Name'])); ?>    
            </div>
            
            <div class="form-group">
                <?php echo e(Form::label('coach', 'Coach')); ?>

                <?php echo e(Form::text('coach', '', ['class' => 'form-control', 'placeholder' => 'Coach'])); ?>  
            </div>

            <div class="form-group">
                <?php echo e(Form::label('group', 'Group')); ?>

                <?php echo e(Form::text('group', '', ['class' => 'form-control', 'placeholder' => 'Group'])); ?>  
            </div>

            <div class="form-group">
                <?php echo e(Form::label('image', 'Flag')); ?>

                <?php echo Form::file('image', array('class' => 'image')); ?>

            </div>

            <?php echo e(Form::submit('Cancel', ['class' => 'btn btn-danger'])); ?>

            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>



        
        </div>
    </div>
<?php else: ?>
    <h2 class="alert alert-danger">Unauthorized!!</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>