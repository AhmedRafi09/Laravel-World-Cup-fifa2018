<?php $__env->startSection('content'); ?>
 <?php if(auth()->user()->isAdmin == 1): ?>
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
        	<h2>EDIT PLAYER INFO</h2>

        	<?php echo e(Form::open(['action' => ['PlayersController@update', $player->id], 'method' => 'POST'])); ?>

        	<div class="form-group">
        		<?php echo e(Form::label('country', 'Country')); ?>

        		<?php echo e(Form::text('country', $player->country, ['class' => 'form-control', 'placeholder' => 'Country'])); ?>	
        	</div>

        	<div class="form-group">
        		<?php echo e(Form::label('name', 'Name')); ?>

        		<?php echo e(Form::text('name', $player->name, ['class' => 'form-control', 'placeholder' => 'Name'])); ?>	
        	</div>

        	<div class="form-group">
        		<?php echo e(Form::label('age', 'Age')); ?>

        		<?php echo e(Form::text('age', $player->age, ['class' => 'form-control', 'placeholder' => 'Age'])); ?>	
        	</div>

        	<div class="form-group">
        		<?php echo e(Form::label('position', 'Position')); ?>

        		<?php echo e(Form::text('position', $player->position, ['class' => 'form-control', 'placeholder' => 'Position'])); ?>	
        	</div>

        	<div class="form-group">
        		<?php echo e(Form::label('matches', 'Matches')); ?>

        		<?php echo e(Form::text('matches', $player->matches, ['class' => 'form-control', 'placeholder' => 'Matches'])); ?>	
        	</div>

            
    		<?php echo e(Form::hidden('_method', 'PUT')); ?>

            <?php echo e(Form::submit('Cancel', ['class' => 'btn btn-danger'])); ?>

            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

			<?php echo e(Form::close()); ?>


        </div>

    </div>
<?php else: ?>
    <h2>Unauthorized Request!</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>


        		
        		
        		
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>