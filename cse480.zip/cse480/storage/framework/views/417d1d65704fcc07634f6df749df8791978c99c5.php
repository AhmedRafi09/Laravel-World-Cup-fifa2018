<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>
    <h2>Unauthorized!</h2>
<?php elseif(Auth::user()->isAdmin == 'NULL'): ?>
    <h2>Unauthorized!</h2>
<?php elseif(auth()->user()->isAdmin == 1): ?>
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
        	<h2>ADD A PLAYER</h2>

        	<?php echo e(Form::open(['action' => 'PlayersController@store', 'method' => 'POST'])); ?>


            <div class="form-group">
                <?php echo e(Form::label('name', 'Name')); ?>

                <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])); ?>    
            </div>
            
        	<div class="form-group">
        		<?php echo e(Form::label('country', 'Country')); ?>

        		<?php echo e(Form::text('country', '', ['class' => 'form-control', 'placeholder' => 'Country'])); ?>	
        	</div>

        	

        	<div class="form-group">
        		<?php echo e(Form::label('age', 'Age')); ?>

        		<?php echo e(Form::text('age', '', ['class' => 'form-control', 'placeholder' => 'Age'])); ?>	
        	</div>

        	<div class="form-group">
        		<?php echo e(Form::label('position', 'Position')); ?>

        		<?php echo e(Form::text('position', '', ['class' => 'form-control', 'placeholder' => 'Position'])); ?>	
        	</div>

        	<div class="form-group">
        		<?php echo e(Form::label('matches', 'Matches')); ?>

        		<?php echo e(Form::text('matches', '', ['class' => 'form-control', 'placeholder' => 'Matches'])); ?>	
        	</div>
            

            
            <?php echo e(Form::hidden('team_id', $player->team_id)); ?>

            <?php echo e(csrf_field()); ?>


    		<?php echo e(Form::submit('Cancel', ['class' => 'btn btn-danger'])); ?>

    		<?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

			<?php echo e(Form::close()); ?>


        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


        		
        		
        		
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>