
<h2>Group D</h2>

  <div class="row">
  	
    <div class="col-md-3">
      <div class="thumbnail">
        <a href="/players" target="_blank">
          <img src="/images/teams/brazil.jpg" alt="Lights" style="width:100%; height: 150px;">
          <div class="caption">
   		  	<h3 style="text-align: center;">Brazil</h3>
          </div>
        </a>
      </div>
    </div>

    <div class="col-md-3">
      <div class="thumbnail">
        <a href="/images/teams/argentina.jpg" target="_blank">
          <img src="/images/teams/argentina.jpg" alt="Nature" style="width:100%; height: 150px;">
          <div class="caption">
            <h3 style="text-align: center;">Argetina</h3>
          </div>
        </a>
      </div>
    </div>

    <div class="col-md-3">
      <div class="thumbnail">
        <a href="/images/teams/argentina.jpg" target="_blank">
          <img src="/images/teams/argentina.jpg" alt="Nature" style="width:100%; height: 150px;">
          <div class="caption">
            <h3 style="text-align: center;">Argetina</h3>
          </div>
        </a>
      </div>
  	</div>
      
      <div class="col-md-3">
	      <div class="thumbnail">
	        <a href="/images/teams/argentina.jpg" target="_blank">
	          <img src="/images/teams/argentina.jpg" alt="Nature" style="width:100%; height: 150px;">
	          <div class="caption">
	            <h3 style="text-align: center;">Argetina</h3>
	          </div>
	        </a>
	      </div>
	   </div>

      <div class="col-md-3">
      <div class="thumbnail">
        <a href="/images/teams/argentina.jpg" target="_blank">
          <img src="/images/teams/argentina.jpg" alt="Nature" style="width:100%; height: 150px;">
          <div class="caption">
            <h3 style="text-align: center;">Argetina</h3>
          </div>
        </a>
      </div>
      </div>

      <div class="col-md-3">
      <div class="thumbnail">
        <a href="/images/teams/argentina.jpg" target="_blank">
          <img src="/images/teams/argentina.jpg" alt="Nature" style="width:100%; height: 150px;">
          <div class="caption">
            <h3 style="text-align: center;">Argetina</h3>
          </div>
        </a>
      </div>
      </div>

      <div class="col-md-3">
      <div class="thumbnail">
        <a href="/images/teams/argentina.jpg" target="_blank">
          <img src="/images/teams/argentina.jpg" alt="Nature" style="width:100%; height: 150px;">
          <div class="caption">
            <h3 style="text-align: center;">Argetina</h3>
          </div>
        </a>
      </div>
      </div>

      <div class="col-md-3">
      <div class="thumbnail">
        <a href="/images/teams/argentina.jpg" target="_blank">
          <img src="/images/teams/argentina.jpg" alt="Nature" style="width:100%; height: 150px;">
          <div class="caption">
            <h3 style="text-align: center;">Argetina</h3>
          </div>
        </a>
      </div>
      </div>
  </div>
