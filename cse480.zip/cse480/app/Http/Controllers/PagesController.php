<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Team;
use Image;
use App\Group;
use DB;

class PagesController extends Controller
{
    //
    public function home(){
    	return view('pages/index');
    }

    public function about(){
    	return view('pages/about');
    }
    /*public function create(){
    	return view('teams/create');
    }*/

    public function dashboard(){
        return view('admin/dashboard');
    }

    public function login(){
        return view('pages/login');
    }

    public function fileUpload(Request $request)

    {

        $avatar = $request->file('image');
        $filename = time() . '.' . $avatar->getClientOriginalExtension();
        Image::make($avatar)->resize(300, 200)->save(public_path('images/uploads/' . $filename));

        return back()->with('status','Image Upload successful');

    }

    public function file(){
        return view('pages/fileUpload');
    }

    public function groups(){
        $groups = Group::orderBy('group_name', 'asc')->get();
        /*$groups = DB::table('groups')->distinct('group_name');*/
        return view('groups.group_info')->with('groups', $groups);
    }

}
