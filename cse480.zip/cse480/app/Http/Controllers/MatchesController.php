<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Match;
use App\Http\Requests\MatchFormRequest;

class MatchesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $matches = Match::orderBy('id', 'asc')->get();
        return view('matches.display')->with('matches', $matches);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('matches.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'venue' => 'required',
            'city' => 'required',
            'team_1' => 'required',
            'goal_team_1' => 'numeric|min:0',
            'team_2' => 'required',
            'goal_team_2' => 'numeric|min:0'
        ]);

        $match = new Match(array(
        'venue' => $request->input('venue'),
        'city' => $request->input('city'),
        'team_1' => $request->input('team_1'),
        'goal_team_1' => $request->input('goal_team_1'),
        'team_2' => $request->input('team_2'),
        'goal_team_2' => $request->input('goal_team_2')
        ));

        $match->save();

        return redirect('/dashboard')->with('status', 'Match Successfully Added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
