<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MatchFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'venue' => 'required',
            'city' => 'required',
            'team_1' => 'required',
            'goal_team_1' => 'required',
            'team_2' => 'required',
            'goal_team_2' => 'required'

        ];
    }
}
