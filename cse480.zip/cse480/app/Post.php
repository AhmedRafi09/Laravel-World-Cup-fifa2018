<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Comment;

class Post extends Model
{
   public function comment(){
   	return $this->hasMany('App\Comment');
   }

   public function addComment($body){
   		$comment = new Comment();
        $comment->post_id = $this->id;
        $comment->body = $body;
        $comment->save();
   }
}
