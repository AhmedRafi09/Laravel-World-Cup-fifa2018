<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Match extends Model
{
    protected $fillable = ['venue', 'city', 'team_1', 'goal_team_1', 'team_2', 'goal_team_2'];

    public function teams()
    {
        return $this->hasMany('App\Team');
    }
}
