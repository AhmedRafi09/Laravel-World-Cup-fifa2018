<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    public function player()
    {
        return $this->hasMany('App\Player');
    }

    public function group()
    {
    	return $this->belongsTo('App\Group');
    }

    protected $fillable = ['team_name', 'coach', 'group'];
}
