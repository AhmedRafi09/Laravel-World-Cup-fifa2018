<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@home');
Route::get('/about', 'PagesController@about');

Route::resource('players', 'PlayersController');
Route::get('/add_player', 'PlayersController@create');
Route::get('/players/edit_player/{id}', 'PlayersController@edit');
/*Route::get('/edit_player/{id}', 'PlayersController@update');*/


Route::resource('teams', 'TeamsController');
Route::get('/create', 'TeamsController@create');
Route::post('/create', 'TeamsController@store');


Route::resource('matches', 'MatchesController');
Route::get('/add', 'MatchesController@create');
Route::post('/add', 'MatchesController@store');

Route::get('/dashboard', 'PagesController@dashboard');
Route::get('/login', 'PagesController@login');


Route::resource('posts', 'PostsController');
Route::get('/posts/{id}', 'PostsController@show');
Route::resource('comments', 'CommentsController');
Route::post('/posts/{id}/comment', 'CommentsController@store');

Route::get('/players/edit_player', 'PlayersController@edit');
Route::get('/players', 'PlayersController@index');



Auth::routes();

Route::get('/user_dashboard', 'UserDashboardController@index');
Route::get('/dashboard', 'AdminController@index');

Route::get('admin/routes', 'AdminController@admin')->middleware('admin');


Route::get('/details/{id}', 'TeamsController@show');


Route::post('/fileUpload', 'PagesController@fileUpload');


Route::get('/groups', 'PagesController@groups');