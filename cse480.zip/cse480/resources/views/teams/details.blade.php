@extends('layouts.app')
@section('content')

	<div class="well" style="width: 100%; text-align: center; background-color: #13395A; color: white;">
		<img src="/images/teams/{{$team->flag}}" alt="Lights" style="width:20%; height: 15%;">
		<h1>{{ $team->team_name }}</h1>
		<h2>Coach/Team Manager : {{ $team->coach }}</h2>
		<p></p> 
	</div>

	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2 style="text-align: center;">Players</h2>
	</div>
	
	<hr>
	{{-- @foreach($team->player as $player)
		<div class="well" style="width: 100%; ">
		  	<div class="row">
		  		<div class="left">
					<h3>{{ $player->name }}</h3>
				</div>
				<div class="right;">
					<h4>{{ $player->position }}</h4>
		    	</div>
		    </div>    
	    </div>
	@endforeach --}}

	<div class="container">
		<table class="table table-light">
		  	<thead>
			    <tr>
			      <th scope="col">Name</th>
			      <th scope="col">Position</th>
			      <th scope="col">Age</th>
			      <th scope="col">Matches</th>
			    </tr>
		  	</thead>
	  	  	<tbody>
				@foreach($team->player as $player)	
				    <tr>
				      <td><h2>{{$player->name}}</h2></td>
				      <td><h3>{{$player->position}}</h3></td>
				      <td><h3>{{$player->age}}</h3></td>
				      <td><h3>{{$player->matches}}</h3></td>
				    </tr>
				@endforeach

	  		</tbody>
		</table>
	</div>

@endsection

{{-- <style type="text/css">
	.row{
		display: flex;
	}
	.left{
		flex: 30%;
	}
	.right{
		flex: 70%;
	}
</style> --}}

