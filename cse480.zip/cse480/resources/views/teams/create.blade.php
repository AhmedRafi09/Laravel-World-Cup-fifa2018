@extends('layouts.app')
@section('content')
@if(auth()->user()->isAdmin == 1)
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
            <h2>Create A Team</h2>

            {{ Form::open(['action' => 'TeamsController@store', 'files' => true, 'method' => 'POST']) }}

            <div class="form-group">
                {{Form::label('team_name', 'Team Name')}}
                {{Form::text('team_name', '', ['class' => 'form-control', 'placeholder' => 'Team Name'])}}    
            </div>
            
            <div class="form-group">
                {{Form::label('coach', 'Coach')}}
                {{Form::text('coach', '', ['class' => 'form-control', 'placeholder' => 'Coach'])}}  
            </div>

            <div class="form-group">
                {{Form::label('group', 'Group')}}
                {{Form::text('group', '', ['class' => 'form-control', 'placeholder' => 'Group'])}}  
            </div>

            <div class="form-group">
                {{Form::label('image', 'Flag')}}
                {!! Form::file('image', array('class' => 'image')) !!}
            </div>

            {{Form::submit('Cancel', ['class' => 'btn btn-danger'])}}
            {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
            {{ Form::close() }}


        
        </div>
    </div>
@else
    <h2 class="alert alert-danger">Unauthorized!!</h2>
@endif
@endsection