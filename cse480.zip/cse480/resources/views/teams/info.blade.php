@extends('layouts.app')
@section('content')
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Teams Of World Cup 2018</h2>
	</div>
	<br>
		
	<div class="row">

		@if(count($teams) > 0)
			@foreach($teams as $team)

			    <div class="col-md-3">
			      <div class="thumbnail">
			        <a href="/details/{{$team->id}}" target="_self" value="{{$team->team_name}}">
			          <img src="/images/teams/{{$team->flag}}" alt="Lights" style="width:100%;">
			          <div class="caption">
			   		  	<h3 style="text-align: center;">{{$team->team_name}}</h3>
			          </div>
			        </a>
			      </div>
			    </div>

			@endforeach
		@else
			<p>No Team Found!</p>
		@endif

	</div>

@endsection














{{-- @extends('layouts.app')
@section('content')
	<div class="container">
		<br><br>
		<table class="table table-light">
		  <thead>
		    <tr>		
		      <th scope="col">Name</th>
		      <th scope="col">Group</th>
		      <th scope="col">Coach</th>  
		    </tr>
		  </thead>
		  <tbody>
			@foreach($teams as $team)
			    <tr>
			      <td>{{$team->team_name}}</td>
			      <td>{{$team->group}}</td>
			      <td>{{$team->coach}}</td>
			    </tr>
			@endforeach
		  </tbody>
		</table>
	</div>


	<div class="container-fluid">
	  <h2>Teams</h2>
	  
	  <p>Click To See The Team!</p>

	  @include('teams.A')
	  @include('teams.B')
	  @include('teams.C')
	  @include('teams.D')
	  @include('teams.E')
	  @include('teams.F')

	</div>
@endsection --}}

{{-- {{ HTML::image('img/myimage.png', 'a picture') }} --}}