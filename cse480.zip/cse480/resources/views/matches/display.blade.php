@extends('layouts.app')
@section('content')

<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
	<h2>Matches From Round Of 16</h2>
</div>
<div class="container">
	@foreach($matches as $match)
	  <div class="well" style="width: 100%;">
	  	<div class="row">
	  		<div class="left">
		  		<h2>{{$match->team_1}}  {{$match->goal_team_1}} - {{$match->goal_team_2}}  {{$match->team_2}}</h2>
	  		</div>
	    
		    <div class="right;">	
				<h4>City: {{$match->city}}</h4>      
		    	<h4>Venue: {{$match->venue}}</h4>
		    </div>
	  	</div>    
	  </div> 
	@endforeach
</div>
     

@endsection

<style type="text/css">
	.row{
		display: flex;
	}
	.left{
		flex: 30%;
	}
	.right{
		flex: 70%;
	}
</style>