@extends('layouts.app')
@section('content')
@if(auth()->user()->isAdmin == 1)
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
            <h2>ADD A PLAYER</h2>

            {{ Form::open(['action' => 'MatchesController@store', 'method' => 'POST']) }}

            <div class="form-group">
                {{Form::label('venue', 'Venue')}}
                {{Form::text('venue', '', ['class' => 'form-control', 'placeholder' => 'Venue'])}}    
            </div>
            
            <div class="form-group">
                {{Form::label('city', 'City')}}
                {{Form::text('city', '', ['class' => 'form-control', 'placeholder' => 'City'])}}  
            </div>

            

            <div class="form-group">
                {{Form::label('team_1', 'First Team')}}
                {{Form::text('team_1', '', ['class' => 'form-control', 'placeholder' => 'First Team'])}}  
            </div>

            <div class="form-group">
                {{Form::label('goal_team_1', 'Goals')}}
                {{Form::text('goal_team_1', '', ['class' => 'form-control', 'placeholder' => 'Goals'])}}    
            </div>

            <div class="form-group">
                {{Form::label('team_2', 'Second Team')}}
                {{Form::text('team_2', '', ['class' => 'form-control', 'placeholder' => 'Second Team'])}}  
            </div>

            <div class="form-group">
                {{Form::label('goal_team_2', 'Goals')}}
                {{Form::text('goal_team_2', '', ['class' => 'form-control', 'placeholder' => 'Goals'])}}    
            </div>

            {{Form::submit('Cancel', ['class' => 'btn btn-danger'])}}
            {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
            {{ Form::close() }}


            {{-- <form class="form-horizontal" method="post"> --}}
                {{-- @foreach ($errors->all() as $error)
                    <p class="alert alert-danger">{{ $error }}</p>
                @endforeach

                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif --}}
                {{-- <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                <fieldset>
                    <legend>Add A Match</legend>
                    <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Venue</label>
                            <div class="col-lg-5">
                                <input type="text" class="form-control" id="venue" placeholder="Venue" name="venue">
                            </div>
                    </div>
                 
                    
					<div class="form-group">
                        <label for="title" class="col-lg-2 control-label">City</label>
                            <div class="col-lg-5">
                                <input type="text" class="form-control" id="city" placeholder="City" name="city">
                            </div>
                    </div>

                    <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Team 1</label>
                            <div class="col-lg-5">
                                <input type="text" class="form-control" id="team_1" placeholder="First Team" name="team_1">
                            </div>
                    </div>
                    <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Goals</label>
                            <div class="col-lg-5">
                                <input type="text" class="form-control" id="goal_team_1" placeholder="Goals of First Team" name="goal_team_1">
                            </div>
                    </div>

                    <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Team 2</label>
                            <div class="col-lg-5">
                                <input type="text" class="form-control" id="team_2" placeholder="Second Team" name="team_2">
                            </div>
                    </div>
                    <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Goals</label>
                            <div class="col-lg-5">
                                <input type="text" class="form-control" id="goal_team_2" placeholder="Goals of Second Team" name="goal_team_2">
                            </div>
                    </div>


                    {{-- <div class="form-group">
	                    <div class="col-4">
					      <label class="mr-sm-2" for="inlineFormCustomSelect">Group</label>
					      <select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
					        <option selected>Choose...</option>
					        <option value="1">A</option>
					        <option value="2">B</option>
					        <option value="3">C</option>
					        <option value="4">D</option>
					        <option value="5">E</option>
					        <option value="6">F</option>
					        <option value="7">G</option>
					        <option value="8">H</option>
					      </select>
					    </div>
					</div> --}}


                    {{-- <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button class="btn btn-default">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>  --}}
        </div>
    </div>
@else
    <h2 class="alert alert-danger">Unauthorized!!</h2>
@endif
@endsection