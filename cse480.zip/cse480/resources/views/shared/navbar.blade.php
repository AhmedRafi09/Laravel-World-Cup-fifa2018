
<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
        <div class="navbar-header">

            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <!-- Branding Image -->
            <a class="navbar-brand" href="{{ url('/') }}">
                {{ config('app.name', 'Laravel') }}
            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav">
                &nbsp;
            </ul>

            <ul class="nav navbar-nav">
                {{-- <li class="nav-item">
                  <a class="nav-link" href="/">Home<span class="sr-only">(current)</span></a>
                </li> --}}
                @if (Auth::guest())
                    <li class="nav-item">
                        <a class="nav-link" href="/matches">MATCHES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/teams">TEAMS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/groups">GROUPS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/players">PLAYERS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">ABOUT</a>
                    </li>
                @elseif(auth()->user()->isAdmin == 1)
                    <li class="nav-item">
                        <a class="nav-link" href="/matches">MATCHES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/teams">TEAMS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/groups">GROUPS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/players">PLAYERS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/posts">BLOG</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/dashboard">DASHBOARD</a>
                    </li>
                @else
                    <li class="nav-item">
                        <a class="nav-link" href="/matches">MATCHES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/teams">TEAMS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/groups">GROUPS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/players">PLAYERS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/posts">BLOG</a>
                    </li>

                    {{-- <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            MORE
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="">STATISTICS</a>
                                <a href="">AWARDS</a>
                                <a href="">SUMMARY</a>
                            </li>
                        </ul>
                    </li> --}}
                @endif

            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                <!-- Authentication Links -->
                @if (Auth::guest())
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('login') }}">LOG IN</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('register') }}">REGISTER</a>
                    </li>
                @else
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            @if(auth()->user()->isAdmin == 1)
                            ADMIN<span class="caret"></span>
                            @else
                            {{ Auth::user()->name }} <span class="caret"></span>
                            @endif
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            @if(auth()->user()->isAdmin == 1)
                                <li><a href="/dashboard">DASHBOARD</a></li>
                            
                                <li>
                                    <a href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        LOG OUT
                                    </a><form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form>
                                </li>
                        
                            @else
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    LOG OUT
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </li>
                            @endif
                        </ul>
                    </li>
                @endif
            </ul>
        </div>
    </div>
</nav>