@extends('layouts.app')
@section('content')
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Players</h2>
		<p></p> 
	</div>
	<br><br>
	<div class="container">
	<table class="table table-light">
	  <thead>
	    <tr>
	      <th scope="col">Name</th>
	      <th scope="col">Country</th>
	      <th scope="col">Age</th>
	      <th scope="col">Position</th>
	      <th scope="col">Matches</th>
	    </tr>
	  </thead>
	  @if(Auth::guest())
	  	 <tbody>
			@foreach($players as $player)	
			    <tr>
			      <td><h2>{{$player->name}}</h2></td>
			      <td><h3>{{$player->country}}</h3></td>
			      <td><h3>{{$player->age}}</h3></td>
			      <td><h3>{{$player->position}}</h3></td>
			      <td><h3>{{$player->matches}}</h3></td>
			    </tr>
			@endforeach

	  </tbody>
	  @elseif(auth()->user()->isAdmin == 1)
	  <tbody>
		@foreach($players as $player)	
		    <tr>
		      <td>{{$player->name}}</td>
		      <td>{{$player->country}}</td>
		      <td>{{$player->age}}</td>
		      <td>{{$player->position}}</td>
		      <td>{{$player->matches}}</td>
		      <td><a href="/players/edit_player/{{$player->id}}" class="btn btn-primary">EDIT</a></td>
		      <td>
		      	{!!Form::open(['action' => ['PlayersController@destroy', $player->id], 'method' => 'POST'])!!}

		      	{!!Form::hidden('_method', 'DELETE')!!}
		      	{!!Form::submit('DELETE', ['class' => 'btn btn-danger'])!!}
		      	{!!Form::close()!!}
		      </td>
		    </tr>
		@endforeach

	  </tbody>

	 @elseif(Auth::user())
	  	<tbody>
		@foreach($players as $player)	
		    <tr>
		      <td>{{$player->name}}</td>
		      <td>{{$player->country}}</td>
		      <td>{{$player->age}}</td>
		      <td>{{$player->position}}</td>
		      <td>{{$player->matches}}</td>
		    </tr>
		@endforeach

	  </tbody>
	  
	 @endif
	</table>
</div>
	
	
{{$players->Links()}}

@endsection