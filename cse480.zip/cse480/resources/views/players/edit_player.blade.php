@extends('layouts.app')
@section('content')
 @if(auth()->user()->isAdmin == 1)
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
        	<h2>EDIT PLAYER INFO</h2>

        	{{Form::open(['action' => ['PlayersController@update', $player->id], 'method' => 'POST'])}}
        	<div class="form-group">
        		{{Form::label('country', 'Country')}}
        		{{Form::text('country', $player->country, ['class' => 'form-control', 'placeholder' => 'Country'])}}	
        	</div>

        	<div class="form-group">
        		{{Form::label('name', 'Name')}}
        		{{Form::text('name', $player->name, ['class' => 'form-control', 'placeholder' => 'Name'])}}	
        	</div>

        	<div class="form-group">
        		{{Form::label('age', 'Age')}}
        		{{Form::text('age', $player->age, ['class' => 'form-control', 'placeholder' => 'Age'])}}	
        	</div>

        	<div class="form-group">
        		{{Form::label('position', 'Position')}}
        		{{Form::text('position', $player->position, ['class' => 'form-control', 'placeholder' => 'Position'])}}	
        	</div>

        	<div class="form-group">
        		{{Form::label('matches', 'Matches')}}
        		{{Form::text('matches', $player->matches, ['class' => 'form-control', 'placeholder' => 'Matches'])}}	
        	</div>

            
    		{{Form::hidden('_method', 'PUT')}}
            {{Form::submit('Cancel', ['class' => 'btn btn-danger'])}}
            {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
			{{ Form::close() }}

        </div>

    </div>
@else
    <h2>Unauthorized Request!</h2>
@endif
@endsection


        		
        		
        		