@extends('layouts.app')
@section('content')
@if(Auth::guest())
    <h2>Unauthorized!</h2>
@elseif(Auth::user()->isAdmin == 'NULL')
    <h2>Unauthorized!</h2>
@elseif(auth()->user()->isAdmin == 1)
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
        	<h2>ADD A PLAYER</h2>

        	{{ Form::open(['action' => 'PlayersController@store', 'method' => 'POST']) }}

            <div class="form-group">
                {{Form::label('name', 'Name')}}
                {{Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])}}    
            </div>
            
        	<div class="form-group">
        		{{Form::label('country', 'Country')}}
        		{{Form::text('country', '', ['class' => 'form-control', 'placeholder' => 'Country'])}}	
        	</div>

        	

        	<div class="form-group">
        		{{Form::label('age', 'Age')}}
        		{{Form::text('age', '', ['class' => 'form-control', 'placeholder' => 'Age'])}}	
        	</div>

        	<div class="form-group">
        		{{Form::label('position', 'Position')}}
        		{{Form::text('position', '', ['class' => 'form-control', 'placeholder' => 'Position'])}}	
        	</div>

        	<div class="form-group">
        		{{Form::label('matches', 'Matches')}}
        		{{Form::text('matches', '', ['class' => 'form-control', 'placeholder' => 'Matches'])}}	
        	</div>
            {{-- {{ Form::hidden('team_id', $team->id) }} --}}

            {{-- <input type="hidden" name="team_id" value="{{ $team->id }}"> --}}
            {{ Form::hidden('team_id', $player->team_id) }}
            {{ csrf_field() }}

    		{{Form::submit('Cancel', ['class' => 'btn btn-danger'])}}
    		{{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
			{{ Form::close() }}

        </div>
    </div>
@endif
@endsection


        		
        		
        		