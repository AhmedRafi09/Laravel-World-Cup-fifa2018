
@extends('layouts.app')
@section('content')
{{-- @if (!Auth::guest()) --}}
	<a href="/posts" class="btn btn-default">Back To All Posts</a>
	<hr>
	<div class="well" style="width: 100%; background-color: #7B1414; color: white;">
		<h2>{{ $post->title }}</h2>
		<small>Written at {{ $post->created_at }}</small>
		<div>
			{{ $post->body }}
		</div>
		
	</div>
	<hr>
	<div class="container">
		<h3>Comments</h3>
		<ul class="list-group">
			@foreach($post->comment as $comment)
				<li class="list-group-item">
					{{-- <strong>{{$user->$id}}</strong> --}}
					<h4>{{ $comment->body }}</h4>
					<h5>{{ $comment->created_at->diffForHumans()}} &nbsp;</h5>
				</li>
				
			@endforeach
		</ul>	
	</div>

	<hr>

	<form method="post" action="/posts/{{ $post->id }}/comment">
			<input type="hidden" name="post_id" value="{{ $post->id }}">
			<input type="hidden" name="user_id" value="{{ auth()->user()->id }}">
			{{ csrf_field() }}
			<div class="form-group">
				<textarea class="form-control" placeholder="Comment Here" name="body"></textarea>
			</div>
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Comment</button>
			</div>
	</form>


{{-- @else
	<h2>Please Login!</h2>
@endif --}}


@endsection