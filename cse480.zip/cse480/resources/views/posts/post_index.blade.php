@extends('layouts.app')
@section('content')
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Blog Posts</h2>
	</div>

	<div class="container">
		@if(count($posts) > 0)
		@foreach($posts as $post)
			<div class="well" style="width: 100%;">
				<h3><a href="/posts/{{$post->id}}">{{$post->title}}</a></h3>
				<small>Written at {{$post->created_at}}</small>
				<br>
				<br>
				@if(auth()->user()->isAdmin == 1)
					<a href="/posts/edit_post/{{$post->id}}" class="btn btn-primary" style="float: left;">EDIT</a>
			      
			      	{!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST'])!!}

			      	{!!Form::hidden('_method', 'DELETE')!!}
			      	{!!Form::submit('DELETE', ['class' => 'btn btn-danger'])!!}
			      	{!!Form::close()!!}
			    @endif
			</div>
			
		@endforeach
		{{$posts->links()}}
	</div>
	
	
	@else
		<p>No Posts Found!</p>
	@endif	
@endsection