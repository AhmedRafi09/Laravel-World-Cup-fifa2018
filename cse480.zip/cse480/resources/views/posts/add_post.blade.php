@extends('layouts.app')

@section('content')
@if(auth()->user()->isAdmin == 1)
	<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
        	<h2>CREATE POST</h2>

        	{{ Form::open(['action' => 'PostsController@store', 'method' => 'POST']) }}
        	<div class="form-group">
        		{{Form::label('title', 'Title')}}
        		{{Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])}}	
        	</div>

        	<div class="form-group">
        		{{Form::label('body', 'Body')}}
        		{{Form::textarea('body', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Body Text'])}}	
        	</div>

    		{{Form::submit('Cancel', ['class' => 'btn btn-danger'])}}
    		{{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
			{{ Form::close() }}

        </div>
    </div>
@else
    <h2 class="alert alert-danger">Unauthorized!!</h2>
@endif
@endsection