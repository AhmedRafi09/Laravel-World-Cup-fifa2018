@extends('layouts.app')
@section('content')
	<div class="well" style="width: 100%; text-align: center; background-color: #001E2D; color: white;">
		<h2>Groups & Standings</h2>
		<p></p> 
	</div>
	
	<br><br>
	 <div class="container">
		<p>{{count($groups)}}</p>
		<table class="table table-light">
		  <thead>
		    <tr>
		      <th scope="col">GRP</th>
		      <th scope="col">Team</th>
		      <th scope="col">MP</th>
		      <th scope="col">W</th>
		      <th scope="col">D</th>
		      <th scope="col">L</th>
		      <th scope="col">GF</th>
		      <th scope="col">GA</th>
		      <th scope="col">+/-</th>
		      <th scope="col">PTS</th>
		    </tr>
		  </thead>
		  @foreach($groups as $group)
		  	<tbody>
				{{-- @foreach($groups as $group) --}}	
				    <tr>
				      <td rowspan='4'><h2><strong>{{$group->group_name}}</strong></h2></td>
				      <td><h3>{{$group->country_name}}</h3></td>
				      <td><h3>{{$group->match_played}}</h3></td>
				      <td><h3>{{$group->match_won}}</h3></td>
				      <td><h3>{{$group->match_drawn}}</h3></td>
				      <td><h3>{{$group->match_lost}}</h3></td>
				      <td><h3>{{$group->goals_for}}</h3></td>
				      <td><h3>{{$group->goals_against}}</h3></td>
				      <td><h3>{{$group->goal_diff}}</h3></td>
				      <td><h3>{{$group->points}}</h3></td>

				    </tr>
				

		  	</tbody>
		 @endforeach
		</table>
	</div>
		
	{{-- {{$players->Links()}} --}}

@endsection