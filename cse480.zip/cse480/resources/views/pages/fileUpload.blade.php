@extends('layouts.app')
@section('content')

	{{ Form::open(['action' => 'PagesController@fileUpload', 'files' => true, 'method' => 'POST']) }}

	<div class="row cancel">

	    <div class="col-md-4">

	        {!! Form::file('image', array('class' => 'image')) !!}

	    </div>

	    <div class="col-md-4">

	        <button type="submit" class="btn btn-success">Upload</button>

	    </div>

	</div>
	{!! Form::close() !!}

@endsection